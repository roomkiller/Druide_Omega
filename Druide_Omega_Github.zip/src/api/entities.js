import { base44 } from './base44Client';


export const Conversation = base44.entities.Conversation;

export const ConsciousnessConfig = base44.entities.ConsciousnessConfig;

export const ConsciousThought = base44.entities.ConsciousThought;

export const TTSPreferences = base44.entities.TTSPreferences;

export const Memory = base44.entities.Memory;

export const KnowledgeBase = base44.entities.KnowledgeBase;

export const VisualContent = base44.entities.VisualContent;

export const KnowledgeDomain = base44.entities.KnowledgeDomain;

export const ConsciousnessEvolution = base44.entities.ConsciousnessEvolution;

export const DailyBriefing = base44.entities.DailyBriefing;

export const EmotionalResponse = base44.entities.EmotionalResponse;

export const CognitiveCorrelation = base44.entities.CognitiveCorrelation;

export const InterpretativeTrace = base44.entities.InterpretativeTrace;

export const MarketAnalysis = base44.entities.MarketAnalysis;

export const KnowledgeFusion = base44.entities.KnowledgeFusion;

export const NeuralModule = base44.entities.NeuralModule;



// auth sdk:
export const User = base44.auth;